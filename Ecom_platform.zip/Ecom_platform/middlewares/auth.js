const jwt = require("jsonwebtoken");
const User = require("../models/User");
const CustomError = require("../utils/errors/CustomError");

const userAuth = async (req, res, next) => {
  let token;
  const { authorization } = req.headers;
  if (authorization && authorization.startsWith("Bearer")) {
    try {
      token = authorization.split(" ")[1];
      if (!token) {
        return next(new CustomError("Unauthorized User, No Token", 404));
      }
      const { _id } = jwt.verify(token, process.env.JWT_SECRET_KEY);
      req.user = await User.findById(_id);
      next();
    } catch (error) {
      console.log(error);
      return next(new CustomError("Unauthorized User, No Access", 500));
    }
  }
};
module.exports = userAuth;

const User = require("../../models/User");

const updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email, age, address } = req.body;
    const updateUser = await User.findByIdAndUpdate(id, {
      $set: {
        name: name,
        email: email,
        age: age,
        address: address,
        // profileimage: req.file.filename
      },
    });
    if (!updateUser) {
      return res.status(404).json("User is not found!");
    }
    await updateUser.save();
    res.status(200).json("User Updated Successsfully");
  } catch (error) {
    res.json(error.message);
  }
};

module.exports = updateUser;

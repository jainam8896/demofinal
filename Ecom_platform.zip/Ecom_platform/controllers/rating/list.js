const Rating = require("../../models/Rating");
const CustomError = require("../../utils/errors/CustomError");

const listRating = async (req, res) => {
    const rating = await Rating.find({});
    if (!rating){
      return next(new CustomError("No Rating found", 404));
    } 
    return res.status(201).send(rating);
  };
  
  module.exports = listRating
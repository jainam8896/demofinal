const Review = require("../../models/Reviews");
const CustomError = require("../../utils/errors/CustomError");

const deleteReview = async (req, res, next) => {
  const { id } = req.params;
  const review = await Review.findByIdAndDelete(id);
  if (!review){
    return next(new CustomError("Review Not Found", 404));
  } 
  return res.send({ status: "success", message: "Review deleted successfully" });
};

module.exports = deleteReview;

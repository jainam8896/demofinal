const Product = require("../../models/Product");
const CustomError = require("../../utils/errors/CustomError");

//Create Product //  (req, res, next)
const createProduct = async (req, res, next) => {
  const { name, description, price, qty, categoryId } = req.body;
  const product = await Product.findOne({ name: name });
  if (product) {
    return next(new CustomError("Product Already Exists", 404));
  }
  const newProduct = new Product({
    name: name,
    description: description,
    price: price,
    qty: qty,
    image: req.file.filename,
    categoryId: categoryId,
  });
  await newProduct.save();
  res
    .status(200)
    .send({ status: "success", message: "Product Added Successfully" });
};

module.exports = createProduct;

const Product = require("../../models/Product");
const pagination = require("../../helper/pagination");

//Display Product
const listProduct = async (req, res) => {
  try {
    const params = req.body;
    const product = await pagination(params, Product);
    res.json(product);
  } catch (error) {
    res.json(error);
  }
};

module.exports = listProduct;

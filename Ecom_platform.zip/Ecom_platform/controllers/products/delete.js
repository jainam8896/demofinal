const Product = require("../../models/Product");
const CustomError = require("../../utils/errors/CustomError");

//Delete Product
const deletProduct = async (req, res, next) => {
  try {
    const { id } = req.params;
    const product = await Product.findByIdAndDelete(id);
    if (!product) {
      return next(new CustomError("Product Not Found", 404));
    }
    res
      .status(200)
      .send({ status: "success", message: "Product Deleted Successfully" });
  } catch (error) {
    res.json(error.message);
  }
};

module.exports = deletProduct;

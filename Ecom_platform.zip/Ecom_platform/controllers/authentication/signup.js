const User = require("../../models/User");
const bcrypt = require("bcrypt");
const { validationResult } = require("express-validator");
const CustomError = require("../../utils/errors/CustomError");

//User signup
const userRegistration = async (req, res, next) => {
  const { name, email, age, password, address } = req.body;
  try {
    const user = await User.findOne({ email: email });
    if (user) {
      return next(new CustomError("Email Already Exists", 404));
    }
    const salt = bcrypt.genSaltSync(10);
    const hasPassword = bcrypt.hashSync(password, salt);
    const doc = new User({
      name: name,
      email: email,
      age: age,
      password: hasPassword,
      address: address,
      profileimage: req.file.filename,
    });
    await doc.save();
    res.send({ status: "success", message: "User Registration Success" });
  } catch (error) {
    console.log(error);
    return next(new CustomError("Unable to Register", 500));
  }
};

module.exports = userRegistration;

const express = require("express");
const router = express.Router();
const rules = require("../utils/validations/category/validation.js");
const validate = require("../middlewares/validate.js");
const createCategory = require("../controllers/categories/create");
const deletcategory = require("../controllers/categories/delete.js");
const listCategory = require("../controllers/categories/list.js");
const getCategory = require("../controllers/categories/get.js");
const updateCategory = require("../controllers/categories/update.js");

//Create Category
router.post("/create", validate(rules.categoryValidation), createCategory);

//Delete Category
router.delete("/:id", deletcategory);

//Display Category
router.post("/", listCategory);

//Get Category
router.get("/:id", getCategory);

//Update Category
router.put("/:id", updateCategory);

module.exports = router;

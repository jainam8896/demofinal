const mongoose = require("mongoose");

const schema = new mongoose.Schema(
  {
    reviews: {
      type: String,
      required: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
    productId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "product",
    },
  },
  { timestamps: true }
);
const Reviews = mongoose.model("Review", schema);
module.exports = Reviews;

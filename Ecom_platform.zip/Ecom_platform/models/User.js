const mongoose = require("mongoose");

const schema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    age: {
      type: Number,
      required: true,
    },
    address: {
      type: String,
      required: true,
    },
    profileimage: {
      type: String,
      required: true,
    },
    password: {
      type: String,
      required: true,
      select: false
    },
    token: {
      type: String,
    },
    attempts: {
      type: Number,
      default: 0,
    },
    lockeTime: {
      type: Date,
    },
  },
  {
    timestamps: true,
  }
);

const User = mongoose.model("user", schema);
module.exports = User;
